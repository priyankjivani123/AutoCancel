<?php

namespace Vdcstore\AutoCancel\Model\Config\Backend;

class PaymentMethodFields extends \Vdcstore\AutoCancel\Model\Config\Backend\Serialized
{

    public function beforeSave()
    {
        $value = $this->getValue();
        if (is_array($value)) {
            unset($value['__empty']);
        }
        $this->setValue($value);
        return parent::beforeSave();
    }
}
