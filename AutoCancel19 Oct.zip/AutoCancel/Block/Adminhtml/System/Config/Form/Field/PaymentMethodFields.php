<?php
namespace Vdcstore\AutoCancel\Block\Adminhtml\System\Config\Form\Field;

class PaymentMethodFields extends \Magento\Config\Block\System\Config\Form\Field\FieldArray\AbstractFieldArray
{
    private $paymentMethodFieldRenderer;

    
    private $unitFieldRenderer;

    private $elementFactory;

    private $PaymentMethodFactory;

    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Data\Form\Element\Factory $elementFactory,
        \Vdcstore\AutoCancel\Model\Config\Source\PaymentMethodFactory $PaymentMethodFactory,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->elementFactory    = $elementFactory;
        $this->PaymentMethodFactory = $PaymentMethodFactory;
        $this->_addAfter = false;
    }

   
    public function _prepareToRender()
    {
        $this->addColumn('payment_method', ['label' => __('Payment Method')]);
        $this->addColumn('duration', ['label' => __('Duration'), 'required' => true,  'class' => 'required-entry validate-number']);
        $this->addColumn('unit', ['label' => __('Unit')]);
    }

   
    public function renderCellTemplate($columnName)
    {
        if ($columnName == 'payment_method' && isset($this->_columns[$columnName])
        ) {
            $options = $this->PaymentMethodFactory->create()->toOptionArray();
            $element = $this->elementFactory->create('select');
            $element->setForm(
                $this->getForm()
            )->setName(
                $this->_getCellInputElementName($columnName)
            )->setHtmlId(
                $this->_getCellInputElementId('<%- _id %>', $columnName)
            )->setValues(
                $options
            );

            return str_replace("\n", '', $element->getElementHtml());
        }

        if ($columnName == 'unit' && isset($this->_columns[$columnName])
        ) {
            $options = ['hours' => __('Hours'), 'days' => __('Days')];
            $element = $this->elementFactory->create('select');
            $element->setForm(
                $this->getForm()
            )->setName(
                $this->_getCellInputElementName($columnName)
            )->setHtmlId(
                $this->_getCellInputElementId('<%- _id %>', $columnName)
            )->setValues(
                $options
            );

            return str_replace("\n", '', $element->getElementHtml());
        }

        return parent::renderCellTemplate($columnName);
    }

    
    public function _prepareArrayRow(\Magento\Framework\DataObject $row)
    {
        $optionExtraAttr = [];
        $optionExtraAttr['option_' . $this->getPaymentMethodFieldMethod()
            ->calcOptionHash($row->getData('payment_method'))]
            = 'selected="selected"';
        $optionExtraAttr['option_' . $this->getUnitFieldRenderer()
            ->calcOptionHash($row->getData('unit'))]
            = 'selected="selected"';
        $row->setData(
            'option_extra_attrs',
            $optionExtraAttr
        );
    }

    
    public function getPaymentMethodFieldMethod()
    {
        $this->paymentMethodFieldRenderer = $this->getLayout()->createBlock(
            \Vdcstore\AutoCancel\Block\Adminhtml\System\Config\Select::class,
            '',
            ['data' => ['is_render_to_js_template' => true]]
        );

        return $this->paymentMethodFieldRenderer;
    }

   
    public function getUnitFieldRenderer()
    {
        $this->unitFieldRenderer = $this->getLayout()->createBlock(
            \Vdcstore\AutoCancel\Block\Adminhtml\System\Config\Select::class,
            '',
            ['data' => ['is_render_to_js_template' => true]]
        );

        return $this->unitFieldRenderer;
    }
}
