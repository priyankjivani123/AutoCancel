<?php

namespace Vdcstore\AutoCancel\Controller\Adminhtml\Index;

use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Vdcstore\AutoCancel\Block\AutoCancel;
use Magento\Sales\Model\OrderFactory;
use Magento\Sales\Model\Order;
use Magento\Sales\Api\OrderManagementInterface;
use Magento\Framework\Stdlib\DateTime\Timezone\LocalizedDateToUtcConverterInterface;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use Vdcstore\AutoCancel\Model\Post;
use Magento\Framework\Message\ManagerInterface;

class Index extends \Magento\Framework\App\Action\Action
{
    protected $_pageFactory;
    protected $Block;
    protected $_date;
    protected $Order;
    protected $orderManagement;
    private $utcConverter;
    private $CollectionFactory;
    private $Post;
    protected $messageManager;


    public function __construct(
        \Magento\Framework\App\Action\Context      $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        AutoCancel                                 $Block,
        TimezoneInterface                          $date,
        OrderFactory                               $Order,
        Order                                      $Orders,
        OrderManagementInterface                   $orderManagement,
        LocalizedDateToUtcConverterInterface       $utcConverter,
        CollectionFactory                          $CollectionFactory,
        Post                                       $Post,
        ManagerInterface                           $messageManager
    ) {
        $this->_pageFactory = $pageFactory;
        $this->Block = $Block;
        $this->date = $date;
        $this->Order = $Order;
        $this->Orders = $Orders;
        $this->orderManagement = $orderManagement;
        $this->utcConverter = $utcConverter;
        $this->CollectionFactory = $CollectionFactory;
        $this->resultFactory = $context->getResultFactory();
        $this->Post = $Post;
        $this->messageManager = $messageManager;
        return parent::__construct($context);
    }

    public function execute()
    {
        $currentDate = $this->date->date()->format('Y-m-d H:i:s');
        $currentHours = $this->date->date()->format('H:i:s');
        $getEnabl = $this->Block->getEnabl();
        $getStartDate = $this->Block->getStartDate();
        $newDate = $this->date->date($getStartDate)->format('Y-m-d H:i:s');
        $getStatus = $this->Block->getStatus();
        $getStatus = explode(",", $getStatus);
        $getApllyOnPaymentMethod = $this->Block->getApllyOnPaymentMethod();

        $getApllyOnPaymentMethodFromConfig = [];
        $unit = [];
        $duration = [];
        foreach ($getApllyOnPaymentMethod as $key => $getApllyOnPaymentMethod)
        {
            $getApllyOnPaymentMethodFromConfig[$key] = $getApllyOnPaymentMethod['payment_method'];
            $unit[$key] = $getApllyOnPaymentMethod['unit'];
            $duration[$key] = $getApllyOnPaymentMethod['duration'];

        }

        foreach ($getStatus as $status) {
            $orderModel = $this->Order->create();
            $orderDatamodel = $orderModel->getCollection()->addFieldToFilter('main_table.status', ['in' => $status])->addFieldToFilter('created_at', array('gteq' => $newDate));

            foreach ($orderDatamodel as $orderDatamodel1) {
                $getdata = $orderDatamodel1->getData();
                $getincreamentid = $getdata['increment_id'];
                $OrderId = $getdata['entity_id'];
                $created_at = $getdata['created_at'];
                $order = $this->Orders->loadByIncrementId($getincreamentid);
                $payment = $order->getPayment();
                $payment = $payment->getMethod();

                if (in_array($payment, $getApllyOnPaymentMethodFromConfig))
                {
                    $arrayindexOfPayment = array_search($payment, $getApllyOnPaymentMethodFromConfig);
                    $DurationValue = $duration[$arrayindexOfPayment];
                    $unitValue = $unit[$arrayindexOfPayment];

                    if ($unitValue == 'hours') {
                        $ConvetintoMinute = $DurationValue;
                        $Hour = (int)$DurationValue;
                        $Miniute = ($ConvetintoMinute - floor($Hour)) * 100;
                        $start = $created_at;
                        $cancelationHour = date('Y-m-d H:i:s', strtotime('+ ' . $Hour . ' hour + ' . $Miniute . ' minutes', strtotime($start)));
                        $this->orderManagement->cancel($OrderId);
                        $Format = $this->Post->setContent("Oreder " . $OrderId . " Was Successfully Cancelled!")->save();
                    }
                    else
                    {
                        $ConviersionDayIntoHour = $DurationValue * 24;
                        $Miniute = "00";
                        $start = $created_at;
                        $cancelationHour = date('Y-m-d H:i:s', strtotime('+ ' . $ConviersionDayIntoHour . ' hour + ' . $Miniute . ' minutes', strtotime($start)));
                        $this->orderManagement->cancel($OrderId);
                        $Format = $this->Post->setContent("Oreder " . $OrderId . " Was Successfully Cancelled!")->save();

                    }

                }

            }
        }

        $resultRedirect = $this->resultRedirectFactory->create();
        $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        $this->messageManager->addSuccess(__("Success"));
                return $resultRedirect;

    }

}
