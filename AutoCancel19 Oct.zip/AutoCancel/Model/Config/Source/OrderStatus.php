<?php

namespace Vdcstore\AutoCancel\Model\Config\Source;

use Magento\Sales\Model\ResourceModel\Order\Status\CollectionFactory;

class OrderStatus implements \Magento\Framework\Option\ArrayInterface
{

    private $options = null;
    private $collectionFactory;

    public function __construct(
        CollectionFactory $collectionFactory
    ) {
        $this->collectionFactory = $collectionFactory;
    }

    public function toOptionArray()
    {
        if ($this->options === null) {
            $statuses = $this->collectionFactory->create();
            $statuses->addFieldToFilter('status', ['in', ['pending', 'pending_payment', 'fraud', 'payment_review', 'processing']])
                ->addAttributeToSort('status', 'desc');
            foreach ($statuses as $status) {
                $this->options[] = [
                    'value' => $status->getStatus(),
                    'label' => $status->getLabel(),
                ];
            }
        }
        return $this->options;
    }
}
