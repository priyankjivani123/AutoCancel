<?php

namespace Vdcstore\AutoCancel\Model\Config\Source\Order;

class Status implements \Magento\Framework\Option\ArrayInterface
{
    public function toOptionArray()
    {
        return [['value' => 'pending', 'label' => __('Pending')], ['value' => 'processing', 'label' => __('Processing')]];
    }


}

