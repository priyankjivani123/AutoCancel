<?php
namespace Vdcstore\AutoCancel\Model\ResourceModel\Post;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected $_idFieldName = 'id';
    protected $_eventPrefix = 'auto_post_collection';
    protected $_eventObject = 'post_collection';

    protected function _construct()
    {
        $this->_init('Vdcstore\AutoCancel\Model\Post', 'Vdcstore\AutoCancel\Model\ResourceModel\Post');
    }
}

?>
