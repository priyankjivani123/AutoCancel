<?php

namespace Vdcstore\AutoCancel\Model\Config\Source;

class PaymentMethod implements \Magento\Framework\Option\ArrayInterface
{
    private $options = null;
    private $paymentConfig;
    private $scopeConfig;

    public function __construct(
        \Magento\Payment\Model\Config                      $paymentConfig,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ) {
        $this->paymentConfig = $paymentConfig;
        $this->scopeConfig = $scopeConfig;
    }

    public function toOptionArray()
    {
        if ($this->options === null) {
            $paymentMethods = $this->paymentConfig->getActiveMethods();
            foreach (array_keys($paymentMethods) as $paymentCode) {
                $paymentTitle = $this->scopeConfig->getValue('payment/' . $paymentCode . '/title');
                $this->options[] = [
                    'value' => $paymentCode,
                    'label' => $paymentTitle,
                ];
            }
        }
        return $this->options;
    }
}
