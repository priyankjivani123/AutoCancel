<?php

namespace Vdcstore\AutoCancel\Block;

class AutoCancel extends \Magento\Framework\View\Element\Template
{
    protected $_storeManager;

    protected $serializer;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Vdcstore\AutoCancel\Helper\Data            $helperdata,
        \Magento\Store\Model\StoreManagerInterface       $storeManager,
        \Magento\Framework\Serialize\SerializerInterface $serializer,
        array                                            $data = []
    )
    {
        parent::__construct($context, $data);
        $this->_storeManager = $storeManager;
         $this->serializer = $serializer;
        $this->helperdata = $helperdata;

    }

    public function getEnabl()
    {
        return $this->helperdata->getGeneralConfig('enable');
    }
    public function getStartDate()
    {
        return $this->helperdata->getGeneralConfig('start_date');
    }

    public function getStatus()
    {
        return $this->helperdata->getGeneralConfig('status');
    }

    public function getApllyOnPaymentMethod()
    {
        $unseriaLize = $this->serializer->unserialize($this->helperdata->getGeneralConfig('apply_on_payment_methods'));

        return $unseriaLize;
    }

   

}
