<?php

namespace Vdcstore\AutoCancel\Controller\Adminhtml\Post;

class Delete extends \Magento\Backend\App\Action
{
	protected function _isAllowed()
	{
		return $this->_authorization->isAllowed('Vdcstore_AutoCancel::news_delete');
	}
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($id) {
            $title = "";
            try {
                $model = $this->_objectManager->create(\Vdcstore\AutoCancel\Model\Post::class);
                $model->load($id);
                $title = $model->getTitle();
                $model->delete();
               $this->messageManager->addSuccess(__('The news has been deleted.'));
               $this->_eventManager->dispatch(
                    'adminhtml_news_on_delete',
                    ['content' => $title, 'status' => 'success']
                );
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                $this->_eventManager->dispatch(
                    'adminhtml_news_on_delete',
                    ['content' => $title, 'status' => 'fail']
                );
                $this->messageManager->addError($e->getMessage());
                return $resultRedirect->setPath('*/*/edit', ['news_id' => $id]);
            }
        }
        $this->messageManager->addError(__('We can\'t find a news to delete.'));
        return $resultRedirect->setPath('*/*/');
    }
}
?>
